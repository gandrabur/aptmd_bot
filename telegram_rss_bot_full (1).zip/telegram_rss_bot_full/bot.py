import os
import feedparser
import requests
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

INCLUDE_FEEDS = [
    "https://telegraph.md/category/actual/feed/",
    "https://telegraph.md/category/social/feed/",
    "https://telegraph.md/category/economic/feed/",
    "https://telegraph.md/category/externe/feed/",
    "https://telegraph.md/category/lifestyle/feed/",
    "https://telegraph.md/category/comunicate/feed/",
    "https://telegraph.md/category/opinii/feed/",
    "https://telegraph.md/category/parteneriate-media/feed/",
    "https://telegraph.md/category/publicitate/feed/"
]

EXCLUDE_FEEDS = [
    "https://telegraph.md/category/politic/feed/"
]

def fetch_feed_entries():
    all_entries = []
    for url in INCLUDE_FEEDS:
        if url not in EXCLUDE_FEEDS:
            feed = feedparser.parse(url)
            for entry in feed.entries:
                all_entries.append({
                    "title": entry.title,
                    "link": entry.link
                })
    return all_entries

def send_messages(entries):
    if not entries:
        return

    message = ""
    for entry in entries:
        message += f"<b>{entry['title']}</b>
<a href='{entry['link']}'>Citește aici</a>

— — —

"

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    data = {
        "chat_id": CHAT_ID,
        "text": message.strip(),
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    requests.post(url, data=data)

def main():
    entries = fetch_feed_entries()
    send_messages(entries)

if __name__ == "__main__":
    main()
